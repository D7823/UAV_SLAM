
/** @} */
/**
 * Copyright (c) 2014 - 2018, Nordic Semiconductor ASA
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 * 1. Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form, except as embedded into a Nordic
 *    Semiconductor ASA integrated circuit in a product or a software update for
 *    such product, must reproduce the above copyright notice, this list of
 *    conditions and the following disclaimer in the documentation and/or other
 *    materials provided with the distribution.
 * 
 * 3. Neither the name of Nordic Semiconductor ASA nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 * 
 * 4. This software, with or without modification, must only be used with a
 *    Nordic Semiconductor ASA integrated circuit.
 * 
 * 5. Any software provided in binary form under this license must not be reverse
 *    engineered, decompiled, modified and/or disassembled.
 * 
 * THIS SOFTWARE IS PROVIDED BY NORDIC SEMICONDUCTOR ASA "AS IS" AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL NORDIC SEMICONDUCTOR ASA OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
/**
 * @brief BLE central receiver,mainly for searching beacons.
 *
 * This example can be a ble signal receiver and identifier.
 * 
 */

#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "nordic_common.h"
#include "nrf_sdh.h"
#include "nrf_sdh_ble.h"
#include "app_timer.h"
#include "bsp_btn_ble.h"
#include "ble.h"
#include "ble_hci.h"
#include "ble_advdata.h"
#include "ble_advertising.h"
#include "ble_conn_params.h"
#include "ble_db_discovery.h"
#include "ble_lbs_c.h"
#include "ble_conn_state.h"
#include "nrf_ble_gatt.h"
#include "nrf_pwr_mgmt.h"
#include <ble_types.h>
#include "nrf_log.h"
#include "nrf_log_ctrl.h"
#include "nrf_log_default_backends.h"
#include "nrfx_twis.h"  //header file for twis
#include "nrf_drv_twis.h"
//#include "bsp.h"

#define APP_BLE_CONN_CFG_TAG      1                                     /**< A tag that refers to the BLE stack configuration we set with @ref sd_ble_cfg_set. Default tag is @ref APP_BLE_CONN_CFG_TAG. */
#define APP_BLE_OBSERVER_PRIO     3                                     /**< Application's BLE observer priority. You shouldn't need to modify this value. */

//#define CENTRAL_SCANNING_LED      BSP_BOARD_LED_0
//#define FAIL_LED                  BSP_BOARD_LED_1
//#define DISCOVERED_LED            BSP_BOARD_LED_2

#define SCAN_INTERVAL             0x0200                               
#define SCAN_WINDOW               0x00A0                                
#define SCAN_DURATION             0x0000                                /**< Duration of the scanning in units of 10 milliseconds. If set to 0x0000, scanning will continue until it is explicitly disabled. */

uint8_t beacon_peer_addr[20][6] = { {0x20,0xBC,0xF6,0x34,0x19,0xD7},//0
                                    {0xAA,0xF5,0x8B,0xE9,0xCA,0xF2},
								                    {0xEA,0x8D,0x4A,0xCE,0x3C,0xF2},
									                  {0xF7,0x00,0xCD,0x6C,0x0F,0xD7},
									                  {0x38,0xEF,0xAA,0xC3,0xF4,0xF7},
									                  {0x5F,0x74,0xC6,0x7C,0x5C,0xFD},//5
									                  {0xB1,0xDA,0x33,0x98,0xD1,0xCA},
		                                {0x3D,0x84,0x9E,0xF9,0x4D,0xD6},
                                    {0xE3,0xB2,0xC6,0x94,0x00,0xCB},
                                    {0x4A,0xC4,0xC6,0x81,0x9D,0xF8},
                                    {0x80,0x4E,0x1C,0xC9,0x49,0xEB},//10
                                    {0xC2,0x66,0xE9,0x27,0xE4,0xC7},
                                    {0x2B,0x12,0xE1,0x09,0xDE,0xF3},
                                    {0x27,0x60,0x71,0x1D,0x9B,0xCC},
                                    {0x57,0xB7,0x40,0xC5,0x7E,0xDC},
                                    {0x20,0x0A,0x66,0x37,0x29,0xE8},//15
                                    {0xE2,0x4F,0xB9,0x39,0xD7,0xF2},
                                    {0x47,0x05,0x50,0x35,0x67,0xF5},
                                    {0x6D,0x6B,0x51,0x9C,0xFC,0xDB},
                                    {0xF3,0xC6,0x24,0xAA,0x79,0xDA}
                                   };


#define NRF_LOG_ENABLED           1
#define NRF_LOG_DEFAULT_LEVEL     3

/* TWI instance ID. */
#define TWIS_INST_ID         0

/* Common addresses definition for the master(STM OR PCA?). */
#define MASTER_ADDR0         0x74
#define MASTER_ADDR1         0
#define NRFX_TWIS_DEFAULT_CONFIG_SCL_PULL  0
#define NRFX_TWIS_DEFAULT_CONFIG_SDA_PULL  0


static int8_t m_rssi[20]={0};                      //the varible used to store the signal strenth from the advertising report of the target device
static uint8_t p_rssi[20]={0};                     //m_rssi+128

//static char const m_target_periph_name[] = "Beacon";       /**< Name of the device we try to connect to.*/

static uint8_t m_scan_buffer_data[BLE_GAP_SCAN_BUFFER_MIN]; /**< buffer where advertising reports will be stored by the SoftDevice. */

/**@brief Pointer to the buffer where advertising reports will be stored by the SoftDevice. */
static ble_data_t m_scan_buffer =
{
    m_scan_buffer_data,
    BLE_GAP_SCAN_BUFFER_MIN
};

/**@brief Scan parameters requested for scanning and connection. */
static ble_gap_scan_params_t const m_scan_params =
{
    .active   = 0,
    .interval = SCAN_INTERVAL,
    .window   = SCAN_WINDOW,

    .timeout           = SCAN_DURATION,
    .scan_phys         = BLE_GAP_PHY_1MBPS,
    .filter_policy     = BLE_GAP_SCAN_FP_ACCEPT_ALL,

};

//creat a structure for the target uuid
/*static ble_uuid_t const m_uuid =
{
      .type  =0x01,//essential, choose the right type, which will affect our central device searching for uuid 
      .uuid  =target_uuid
};
*/




/* TWIS instance. */
static const nrfx_twis_t m_twis = NRFX_TWIS_INSTANCE(TWIS_INST_ID);

int8_t received_value;




/**@brief Function to handle asserts in the SoftDevice.
 *
 * @details This function will be called in case of an assert in the SoftDevice.
 *
 * @warning This handler is an example only and does not fit a final product. You need to analyze
 *          how your product is supposed to react in case of Assert.
 * @warning On assert from the SoftDevice, the system can only recover on reset.
 *
 * @param[in] line_num     Line number of the failing ASSERT call.
 * @param[in] p_file_name  File name of the failing ASSERT call.
 */
void assert_nrf_callback(uint16_t line_num, const uint8_t * p_file_name)
{
    app_error_handler(0xDEADBEEF, line_num, p_file_name);
}


/*Function to compare the peer address.*/
static int compare_peer_addr(uint8_t received_peer[6])
{
  int count=0;
  for(int i=0;i<20;i++)
	{
		count=0;
		// ignore the rest with 0 addr
		if(beacon_peer_addr[i][0]==0)
			continue;
		for(int j=0;j<6;j++)
		{
			if(received_peer[j]!=beacon_peer_addr[i][j])
				break;
			++count;
		}
		if(count==6)
		{
			 return i; 
		}	
	}
	return -1;//no match
}

/**
 * @brief TWIS events handler.
 */
void twis_handler(nrfx_twis_evt_t const * p_event)
{
    switch (p_event->type)
    {
    //if get a reading request from the master
    case NRFX_TWIS_EVT_READ_REQ:
       if(p_event->data.buf_req) 
       {
            nrfx_twis_tx_prepare(&m_twis, p_rssi, sizeof(p_rssi));
            NRF_LOG_INFO("TWIS get data transfer request.\n");    
       }
       break;
   //once the reading is succfully done, clear the data buffer
   case NRFX_TWIS_EVT_READ_DONE:
        for(int i=0;i<20;i++)
        	p_rssi[i]=0;
        NRF_LOG_INFO("TWIS data transfer done.\n");
       break;
	
	case NRFX_TWIS_EVT_WRITE_REQ:
			
       if(p_event->data.buf_req) {
           nrfx_twis_rx_prepare(&m_twis, &received_value, sizeof(&received_value));
       }		   
       break;
   case NRFX_TWIS_EVT_WRITE_DONE:
      break;	 
    default:
       break;
    }
}

/**
 * @brief twis initialization.
 */
void twis_init (void)
{
    ret_code_t err_code;

    const nrfx_twis_config_t m_twis_config = {
       .addr               = {MASTER_ADDR0, MASTER_ADDR1},
       .scl                = 27,
       .sda                = 26,
       .interrupt_priority = APP_IRQ_PRIORITY_HIGH,
    };

    err_code = nrfx_twis_init(&m_twis, &m_twis_config, twis_handler);
    APP_ERROR_CHECK(err_code);

    nrfx_twis_enable(&m_twis);
    NRF_LOG_INFO("TWIS initiation success.\n");
}


/**@brief Function to start scanning. */
static void scan_start(void)
{
    ret_code_t ret;

    (void) sd_ble_gap_scan_stop();

    //NRF_LOG_INFO("Start scanning for device name %s.", (uint32_t)m_target_periph_name);
    ret = sd_ble_gap_scan_start(&m_scan_params, &m_scan_buffer);
    APP_ERROR_CHECK(ret);
    // Turn on the LED to signal scanning.
    //bsp_board_led_on(CENTRAL_SCANNING_LED);
}

/**@brief Function for handling the advertising report BLE event.
 *
 * @param[in] p_adv_report  Advertising report from the SoftDevice.
 */
static void on_adv_report(ble_gap_evt_adv_report_t const * p_adv_report)
{

  uint8_t j=0;   //variable for printing out the peer address from the advertising report of our target device 
	uint8_t p_peer_address[6];
	ret_code_t err_code;
   
    //print out the peer address of the target device
    while (j<6)
	{
	  p_peer_address[j]=p_adv_report->peer_addr.addr[j];
      ++j;
	 }

	//matching the peer address 
	int beacon_id=compare_peer_addr(p_peer_address);
	if (beacon_id!=-1)
	{
		m_rssi[beacon_id] = p_adv_report->rssi;
		p_rssi[beacon_id] = m_rssi[beacon_id]+128;//+128 for encoding
		NRF_LOG_INFO("beacon %d: %d",beacon_id, m_rssi[beacon_id]);
	}  	
    err_code = sd_ble_gap_scan_start(NULL, &m_scan_buffer);
    APP_ERROR_CHECK(err_code);
}


/**@brief Function for handling BLE events.
 *
 * @param[in]   p_ble_evt   Bluetooth stack event.
 * @param[in]   p_context   Unused.
 */
static void ble_evt_handler(ble_evt_t const * p_ble_evt, void * p_context)
{
    //ret_code_t err_code;

    // For readability.
    ble_gap_evt_t const * p_gap_evt = &p_ble_evt->evt.gap_evt;

    switch (p_ble_evt->header.evt_id)
    {
        //once receive the advertising report, implement the report handler
        //potential changed: directly receive RSSI report might be more sensitive
        case BLE_GAP_EVT_ADV_REPORT:
            on_adv_report(&p_gap_evt->params.adv_report);
            break;
    
        default:
            // No implementation needed.
            break;
    }
}

/**@brief Function for initializing the BLE stack.
 *
 * @details Initializes the SoftDevice and the BLE event interrupts.
 */
static void ble_stack_init(void)
{
    ret_code_t err_code;

    err_code = nrf_sdh_enable_request();
    APP_ERROR_CHECK(err_code);

    // Configure the BLE stack using the default settings.
    // Fetch the start address of the application RAM.
    uint32_t ram_start = 0;
    err_code = nrf_sdh_ble_default_cfg_set(APP_BLE_CONN_CFG_TAG, &ram_start);
    APP_ERROR_CHECK(err_code);

    // Enable BLE stack.
    err_code = nrf_sdh_ble_enable(&ram_start);
    APP_ERROR_CHECK(err_code);

    // Register a handler for BLE events.
    NRF_SDH_BLE_OBSERVER(m_ble_observer, APP_BLE_OBSERVER_PRIO, ble_evt_handler, NULL);
}


/**@brief Function for initializing power management.
 */
static void power_management_init(void)
{
    ret_code_t err_code;
    err_code = nrf_pwr_mgmt_init();
    APP_ERROR_CHECK(err_code);
}


/**@brief Function for handling the idle state (main loop).
 *
 * @details Handle any pending log operation(s), then sleep until the next event occurs.
 */
static void idle_state_handle(void)
{
    if (NRF_LOG_PROCESS() == false)
    {
        nrf_pwr_mgmt_run();
    }
}


/** @brief Function for initializing the log module.
 */
static void log_init(void)
{
    ret_code_t err_code = NRF_LOG_INIT(NULL);
    APP_ERROR_CHECK(err_code);

    NRF_LOG_DEFAULT_BACKENDS_INIT();
}



int main(void)
{
	  //include the target peer address
	  
	  
    // Initialize.
    log_init();
    //leds_init();
    power_management_init();
    ble_stack_init();
    ble_conn_state_init();
    twis_init();

    // Start execution.
    NRF_LOG_INFO("BLE and I2C started.");
    scan_start();

    for (;;)
    {
        idle_state_handle();
    }
}
